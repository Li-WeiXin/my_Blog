const { execSync, spawn } = require('child_process');
const { exit } = require('process');

// 获取命令行参数
const args = process.argv.slice(2);
const command = args[0];
const IS_ALPHA = command && command.includes("--alpha");

// 从环境变量中获取 NPM_TOKEN
const FX_NPM_TOKEN = process.env.FX_NPM_TOKEN;

const { downloadAndUnzipArtifacts } = require("./utils")


// TODO: 检查是否有 alpha 版本 -> 暂不使用prepatch
// const versions = getPackagesVersions();
// console.log('Package versions:', versions);

// const hasAlphaVersion = Object.values(versions).some(version => version.includes('alpha'));

function publishNpm() {
  console.log("=========================== 开始发布 NPM 包 ===========================")
  console.log('FX_NPM_TOKEN:', FX_NPM_TOKEN);
  
  execSync(
    `echo "\\n//npmmirror.nioint.com/:_authToken=${FX_NPM_TOKEN}" >> ./.npmrc`
  );


  try {
    const publishResult = IS_ALPHA ? execSync(`lerna publish from-package --no-private --dist-tag alpha --yes --no-git-reset`, {
      stdio: "inherit"
    }) : execSync(`lerna publish from-package --no-private --dist-tag latest --yes --no-git-reset`, {
      stdio: "inherit"
    })
    if (publishResult) {
      console.error(publishResult);
      console.log("========================== 发布 NPM 包失败 ==========================");
      exit(1);
    } else {
      console.log("========================== 发布 NPM 包成功 ==========================");
    }
  } catch (error) {
    console.error(error);
    console.log("========================== 发布 NPM 包失败 ==========================");
  }

}

function main() {
  downloadAndUnzipArtifacts('dist');
  publishNpm();
}

main();