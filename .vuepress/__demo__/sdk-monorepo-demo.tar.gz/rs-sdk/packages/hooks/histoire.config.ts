import { createHistoireConfig } from '@nio-wad/fx-comp-kit/dist/histoire.config';

const config = createHistoireConfig({ title: 'FX Material' });

if (config.vite) {
  (config.vite as any).base = '/hooks/';
}

export default config;
