const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const FX_BUILD_ID = process.env.FX_BUILD_ID;
const FX_APP_CODE = process.env.FX_APP_CODE;
const FX_NPM_TOKEN = process.env.FX_NPM_TOKEN;

// 获取命令行参数
const args = process.argv.slice(2);
const command = args[0];
const IS_ALPHA = command && command.includes("--alpha");

const { fxJsonContent, indexSrcPath, fxJsonSrcPath } = require("./utils")

function copy(from, to) {
  if (!fs.existsSync(from)) {
    console.log(`Source path ${from} does not exist`);
    return;
  }
  fs.cpSync(from, to, { recursive: true });
}

/**
 * 1. 确保项目根目录下的 dist 目录存在，并将 index.html 文件复制到该目录。
 * 2. 此函数首先检查 dist 目录是否存在，如果不存在则创建它。
 * 3. 然后将 index.html 文件从源路径复制到 dist 目录。
 * 4. 上传dist中的html
 */
function ensureDistDirectoryAndCopyIndex() {
  const projectRoot = path.resolve(__dirname, '../../');
  const distRootDir = path.join(projectRoot, 'dist');
  const indexDestPath = path.join(distRootDir, 'index.html');
  const fxJsonDestPath = path.join(distRootDir, 'fx.json');

  copy(indexSrcPath, indexDestPath);
  copy(fxJsonSrcPath, fxJsonDestPath);
  // 打印distRootDir下文件
  const files = fs.readdirSync(distRootDir);
  console.log(`Copied index.html to ${indexDestPath}, Files in dist directory:`, files);

  try {
    IS_ALPHA
    ? execSync(
        `fx publish --env dev --build ${FX_BUILD_ID} --tag latest --code ${FX_APP_CODE} --sso 1 --region cn --external 0 --use-fms --no-refresh`, {
          stdio: "inherit"
        }
      )
    : execSync(
        `fx publish --env prod --build ${FX_BUILD_ID} --tag latest --code ${FX_APP_CODE} --sso 1 --region cn --external 0 --use-fms --no-refresh`, {
          stdio: "inherit"
        }
      );
  } catch (error) {
    console.error(`Failed to publish docs for package ${distRootDir}, Error:::`, error);
  }
}

function downloadUnzipAndPublish($scene) {
  const packagesDir = path.resolve(__dirname, '../../packages');
  const packages = fs.readdirSync(packagesDir);

  packages.forEach(pkg => {
    const pkgPath = path.join(packagesDir, pkg);
    const distZipPath = path.join(pkgPath, `${$scene}.zip`);
    const distDir = path.join(pkgPath, 'dist');
    const fxJsonPath = path.join(distDir, 'fx.json');

    // console.log('distZipPath', distZipPath);

    // 创建一个临时目录用于解压缩文件
    const tempUnzipPath = path.join(pkgPath, `${$scene}-temp`);

    try {
      execSync(`fx download-artifact --name "${pkg}_${$scene}.${FX_BUILD_ID}" --path "${distZipPath}"`);
      if (fs.existsSync(distZipPath)) {
        console.log(`========================== ${distZipPath} 开始解压 ==========================`);
        // 将 .zip 文件解压到临时目录
        execSync(`unzip "${distZipPath}" -d "${tempUnzipPath}"`);
        // 将临时目录中的文件复制到 dist 目录中
        copy(tempUnzipPath, distDir);
        // 删除临时目录/删除原始的 .zip 文件
        fs.rmSync(tempUnzipPath, { recursive: true, force: true });
        fs.unlinkSync(distZipPath);
      }

      if (fs.existsSync(distDir) && fs.readdirSync(distDir).length > 0) {
        console.log(`========================== 解压 ${pkg}/${$scene} 成功 ==========================`);
        try {
          process.chdir(pkgPath);
          console.log('更改后的工作目录:', process.cwd());

          fs.writeFileSync(fxJsonPath, JSON.stringify(fxJsonContent, null, 2));
          
          IS_ALPHA
            ? execSync(
                `fx publish --env dev --build ${FX_BUILD_ID} --assets-prefix ${pkg}/ --tag latest --code ${FX_APP_CODE} --sso 1 --region cn --external 0 --use-fms --no-refresh`, {
                  stdio: "inherit"
                }
              )
            : execSync(
                `fx publish --env prod --build ${FX_BUILD_ID} --assets-prefix ${pkg}/ --tag latest --code ${FX_APP_CODE} --sso 1 --region cn --external 0 --use-fms --no-refresh`, {
                  stdio: "inherit"
                }
              );

          // 检查是否存在 fx.json 文件并打印其内容
          const files = fs.readdirSync(path.join(pkgPath, 'dist'));
          console.log(`Files in dist directory for package ${pkg}:`, files);

          IS_ALPHA
            ? execSync(
                `fx attach-preview-url --name '资源服务工具库文档' --url https://rs-sdk-dev.nioint.com`, {
                  stdio: "inherit"
                }
              )
            : execSync(
                `fx attach-preview-url --name '资源服务工具库文档' --url https://rs-sdk.nioint.com`, {
                  stdio: "inherit"
                }
              );
          
          const deploymentUrl = `https://rs-sdk${IS_ALPHA ? '-dev' : ''}.nioint.com/${pkg}`;
          
          console.log(`\x1b[1m\x1b[32m查看当前文档部署：${deploymentUrl}\x1b[0m`);

          console.log("========================== 发布 DOC 文档 成功 ==========================");
        } catch (error) {
          console.error(`Failed to publish docs for package ${pkg}, Error:::`, error);
          console.log("========================== 发布 DOC 文档 失败 ==========================");
          process.exit(1);
        }
      } else {
        console.log(`No files found in docs directory for package ${pkg}`);
        // console.log("========================== 发布 DOC 文档 失败 ==========================");
      }
    } catch (error) {
      console.error(`Failed to download or unzip ${$scene} for package ${pkg}:`, error);
      process.exit(1);
      // console.log(`========================== 解压 ${$scene} 失败 ==========================`);
    }
  });
}

function main() {
  execSync(
    `echo "\\n//npmmirror.nioint.com/:_authToken=${FX_NPM_TOKEN}" >> ./.npmrc`
  );
  // 将index.html 复制到项目根目录的dist目录下
  ensureDistDirectoryAndCopyIndex();
  downloadUnzipAndPublish('docs');
  console.log("========================== 发布 DOC 文档 完成 ==========================");
}

main();