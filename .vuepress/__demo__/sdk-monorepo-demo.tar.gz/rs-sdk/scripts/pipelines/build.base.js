/**
 * @description 构建基础文件
 * 当前方案打包到每个pkg的dist文件下，然后再上传到npm
 * 该方案暂时废弃 copy build package dest -> 暂时不提升至pkg-temp / doc-temp
 */
const path = require("path")
const fs = require("fs");
// @ts-ignore
const json5 = require("require-json5")

const { projectNameToDir, copy, cwd, clearDirectory } = require("./utils")

// 获取命令行参数
const args = process.argv.slice(2);
const command = args[0];

// console.log('command => ', command)
const packageDestPath = command === '--build-lib' ? path.resolve(cwd, "pkg-temp") : path.resolve(cwd, "doc-temp")

/**
 * 
 * 1. 从 sdk.json 中获取需要构建的项目
 * 2. 从项目的 package.json 中获取需要上传的文件
 * 3. NPM复制文件到 pkg-temp 目录下 
 * 4. DOC复制文件到 doc-temp 目录下
 */
function copyBaseNpmDist() {
  const sdkJson = json5(path.resolve(cwd, "./sdk.json"))

  const publishProjects = sdkJson.projects
  console.log(publishProjects)

  // 清除 packageDestPath 目录中的文件
  clearDirectory(packageDestPath);

  publishProjects.forEach(project => {
    const projectPath = path.resolve(cwd, project.projectFolder)
    const projectPackageJsonPath = path.resolve(projectPath, "./package.json")

    // 检查 package.json 是否存在
    if (!fs.existsSync(projectPackageJsonPath)) {
      console.log(`Skipping ${project.projectFolder} as package.json does not exist`);
      return;
    }
    
    const pkgJson = require(projectPackageJsonPath)
    if (command === '--build-lib' && !pkgJson.scripts?.["build:lib"]) {
      return;
    }
    if (command === '--build-doc' && !pkgJson.scripts?.["build:doc"]) {
      return;
    }
    const files = pkgJson?.["upload-artifact-files"] ?? ["dist"]

    files.forEach(file => {
      const to = path.resolve(cwd, packageDestPath, projectNameToDir(project.packageName), file.replace(/^dist/, ''))
      const from = path.resolve(projectPath, file)

      copy(from, to)
    })

    console.log('files:', files)
  })
}
copyBaseNpmDist()