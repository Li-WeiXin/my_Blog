const { execSync, spawnSync } = require('child_process');
const { exit } = require('process');
const { deleteExistingTag } = require("./utils")

// 获取命令行参数
const args = process.argv.slice(2);
const command = args[0];
const IS_ALPHA = command && command.includes("--alpha");

// TODO: 检查是否有 alpha 版本 -> 暂不使用prepatch
// const versions = getPackagesVersions();
// console.log('Package versions:', versions);

// const hasAlphaVersion = Object.values(versions).some(version => version.includes('alpha'));

const versionTag = IS_ALPHA ? 'prerelease' : 'patch';

function versionControl() {
  console.log("============================ 修改版本号 ============================")

  try {
    // 忽略了任何非预发布的包。
    // 如果对未指定的包（如果指定包）或不在预发行版中的包进行了更改，则这些包将按通常使用的常规提交进行版本控制。
    const versionResult = IS_ALPHA
      ? execSync(
          `lerna version ${versionTag} --no-private --conventional-commits --include-merged-tags --yes`,
          {
            stdio: 'inherit',
          }
        )
      : execSync(
          `lerna version ${versionTag} --no-private --conventional-commits --conventional-graduate --include-merged-tags --yes`,
          {
            stdio: 'inherit',
          }
        );
  
    if (versionResult) {
      console.error(versionResult);
      console.log("============================ 版本更新失败 ============================");
      exit(1);
    } else {
      console.log("============================ 版本更新成功 ============================");
    }
  } catch (error) {
    // version重复报错处理
    if (error.message.includes('tag already exists')) {
      const tagMatch = error.message.match(/tag '([^']+)' already exists/);
      if (tagMatch) {
        const existingTag = tagMatch[1];
        deleteExistingTag(existingTag);
        versionControl(); // Retry publishing after deleting the existing tag
        return;
      }
    } else {
      console.error(error);
    }
    console.log( '============================ 版本更新失败 ============================');
  }
}

function main() {
  // spawnSync('npm', ['set', '//npmmirror.nioint.com/:_authToken', 'cnpm_1IzutAOxBR4tTiTONMNrG9agvUZTzEmmR_MstVR']);
  // const result = spawnSync('npm', ['config', 'ls']);

  // console.log(result.stdout.toString());

  versionControl();
}

main();