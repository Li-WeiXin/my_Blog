<template>
  <Story>
    <button @click="refetch">重新发起请求</button>
    <div>请求 https://static.nio.com/fx-static/3524/fixed/testObject.test.json，结果：</div>
    <div>
      {{ !loading ? JSON.stringify(result) : 'loading...' }}
      {{ error ? '#error: ' + JSON.stringify(error) : '' }}
    </div>
  </Story>
</template>

<script setup lang="ts">
import './fix-histoire-bug';
import useNativeFetch from './hooks/useNativeFetch';
import { addInterceptor } from './hooks/useFetch';
import { watch } from 'vue';

addInterceptor('request', (config) => {
  if (!config.params) config.params = {};
  config.params.brand = 'alps';
  return config;
});

const {
  data: result, 
  error,
  loading,
  query
} = useNativeFetch<{
  data?: {
    id: string;
    name: string;
  }
}>(`https://gateway-front-external-test.nioint.com/moat/101762/alps/app/bff/map/resources/v1/charge/CS-XX-66aa0b1c-f7b35d82?app_ver=9.21.0&client=alps_app&container=brower&lang=zh&region=CN&app_id=100157&origin_app_id=10002&origin_longitude=114.34748840&origin_latitude=30.54909515&timestamp=1712123402003`, {
  _useInterceptors: [['transformToCamelCase']]
}, true);
query();

function refetch() {
  query({
    url: `https://gateway-front-external-test.nioint.com/moat/101762/alps/app/bff/map/resources/v1/swap/PS-NIO-9178ca4d-05e89c84?app_ver=9.21.0&client=alps_app&container=brower&lang=zh&region=CN&app_id=100157&origin_app_id=10002&brand=alps&origin_longitude=114.34748840&origin_latitude=30.54909515&timestamp=1715586485066`
  }, true)
}

watch(result, (result) => {
  window.alert(result?.data?.name);
});

</script>
