declare namespace dsBridge {
  interface GetAppInfoResult {
    env: ENV;
    lang: string;
    language: string;
    region: string;
    is_dark_mode: boolean;
    app_name: string;
    city_code: string;
    city_name: string;
    pure_mode: number;
    translate_function_status: number;
    translate_lang: string;
    version: string;
  }
  function call(method: 'getAppInfo'): Result<GetAppInfoResult>;
  interface PowerChannelResult {
    request_jsonstring: string;
  }
  function call(method: 'power_channel_method_by_h5', params: string, result: (value: Result<PowerChannelResult>) => void): void;
};

interface Window {
  PE_MFE: any;
  _dsbridge: any;
  _nio_jsbridge_ref: any;
}
