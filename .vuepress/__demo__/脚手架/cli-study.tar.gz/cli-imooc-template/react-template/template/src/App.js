function App() {
  return (
    <div className="App">
      hello cli-imooc;
    </div>
  );
}

export default App;
