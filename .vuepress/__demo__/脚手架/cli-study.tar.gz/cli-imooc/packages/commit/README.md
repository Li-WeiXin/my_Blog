# `commit`

> TODO: description

## Usage

```
const commit = require('commit');

// TODO: DEMONSTRATE API
```
