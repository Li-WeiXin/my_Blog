<template>
  <Story>
    <p>
      不支持的图片，自动 fallback
      <img :src="unSupportedUrl" />
    </p>
    <p>
      支持的图片
      <img :src="supportedUrl" />
    </p>
  </Story>
</template>
<script setup lang="ts">
import './fix-histoire-bug';
import useOptimizeImage from './hooks/useOptimizeImage';

const unSupportedUrl = useOptimizeImage({
  url: 'https://cdn-titan.nio.com/titan-fe/%E8%BF%90%E6%B2%B3%E4%B8%8A%E5%8D%88%E5%86%851%E5%8E%8B2.jpg/1702369401980',
  width: 120,
  height: 120
});
const supportedUrl = useOptimizeImage({
  url: 'https://cdn-udp-public-dev.nio.com/vas/merchant_commodity/163b4193-9a80-40dc-ad4c-c10f4ef6448b.jpg',
  width: 120,
  height: 120
});


</script>
<style>
img {
  width: 60px;
  height: 60px;
}
</style>
