// For some reason histoire uses SSR which causes axios raise an error while compiling.
// Setting navigator.product to 'NativeScript' makes axios think it's in a non-browser environment,
// skipping the problematic logic
if (window.location.href === '//') {
    Object.defineProperty(navigator, 'product', {
        value: 'NativeScript'
    });
    console.log('edited', navigator.product);
}

export {}
