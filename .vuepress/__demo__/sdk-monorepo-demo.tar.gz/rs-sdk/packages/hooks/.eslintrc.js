/**
 * @description eslint 配置
 * @version v1.0.0
 */
const { deepMerge, eslintConfig } = require('@rs-sdk/shared');

module.exports = deepMerge({}, eslintConfig({ tsconfig: './tsconfig.json' }));
