export type ENV = 'local' | 'dev' | 'test' | 'stg' | 'prod';

const DOMAIN_LIST = 'nio(int)?\\.com|onvo\\.cn|nio\\.cn|firefly\\.com\\.cn';

const ua = navigator.userAgent;
export const isInApp = [
  "nio-lifestyle",
  "Lifestyle",
  "niopower",
  "NIOPower",
  "NioPower",
  "_dsbridge",
  "webview/lg"
].some((falg) => ua.indexOf(falg) > -1);

// export const isInApp = (typeof window._dsbridge !== 'undefined' && window._dsbridge.call) || (typeof window._nio_jsbridge_ref !== 'undefined')||;


export function getEnv() {
  let env: ENV = 'prod';

  if (isInApp) {
    // in app
    const appInfo = (dsBridge || window._dsbridge).call('getAppInfo');
    if (appInfo?.result_code === 'success') {
      env = appInfo.data.env;
    }
  } else  if (window.PE_MFE && window.PE_MFE.env) {
    // for PowerGo

    env = window.PE_MFE.env;
  } else {
    // try to infer env from current domain
    const origin=location.origin;
    const domain = window.location.hostname;
    if (domain === "localhost"||/^((ht|f)tps?:\/\/)?[\w-]+(\.[\w-]+)+:\d{1,5}\/?$/.test(origin)) {
      // for access from localhost or ip address
      
      env = "local";
    } else {
        const resMatch = domain.match(new RegExp(`-(local|dev|test|stg).*\\.(${DOMAIN_LIST})$`));
        if (resMatch) {
          env = (resMatch[1] as ENV) || "prod";
        }
    }
  }

  return env;
}
