const { execSync } = require("child_process")
const path = require("path")
const fs = require("fs")

const cwd = process.cwd()
const destPath = path.resolve(cwd, "dist")
const fxJsonContent = require("../fx.json")
// 文档对外文件
const indexSrcPath = path.resolve(cwd, "./doc-sites/index.html")
const fxJsonSrcPath = path.resolve(cwd, "./scripts/fx.json")

const FX_BUILD_ID = process.env.FX_BUILD_ID;

function projectNameToDir (packageName) {
  return packageName.replace("@nio-fe/", "")
}

function copy (from, to) {
  console.log("from:", from, "to:", to)
  if (!fs.existsSync(from)) {
    console.log("from:", from, " is not exits")
    return
  }
  fs.cpSync(from, to, {
    recursive: true,
  })
}

function cleanDist() {
  fs.rmSync(destPath, {
    recursive: true,
  })
}

function safeParse(str) {
  try {
    return JSON.parse(str)
  } catch (err) {
    return {}
  }
}

function clearDirectory(directory) {
  if (fs.existsSync(directory)) {
    fs.readdirSync(directory).forEach((file) => {
      const curPath = path.join(directory, file);
      if (fs.lstatSync(curPath).isDirectory()) {
        clearDirectory(curPath);
        fs.rmdirSync(curPath);
      } else {
        fs.unlinkSync(curPath);
      }
    });
  }
}

/**
 * 用于获取位于 packages 目录下所有包的版本信息
 */
function getPackagesVersions() {
  const packagesDir = path.resolve(__dirname, '../../packages');
  const packages = fs.readdirSync(packagesDir);
  const versions = {};

  packages.forEach(pkg => {
    const pkgPath = path.join(packagesDir, pkg, 'package.json');
    if (fs.existsSync(pkgPath)) {
      const pkgJson = require(pkgPath);
      versions[pkg] = pkgJson.version;
    }
  });

  return versions;
}

/**
 * 用于确保当前分支是有效的
 */
function ensureOnBranch() {
  try {
    const branch = execSync('git symbolic-ref --short HEAD').toString().trim();
    console.log(`Current branch: ${branch}`);
  } catch (error) {
    console.error('Not on a valid branch. Please checkout a branch to proceed.');
    process.exit(1);
  }
}
/**
 * 用于删除已存在的标签
 */
function deleteExistingTag(tag) {
  try {
    execSync(`git tag -d ${tag}`);
    execSync(`git push origin --delete ${tag}`);
    console.log(`Deleted existing tag: ${tag}`);
  } catch (error) {
    console.error(`Failed to delete existing tag: ${tag}`);
  }
}

/**
 * 用于下载并解压 artifacts
 * 支持下载 docs 和 dist 两种场景
 */
function downloadAndUnzipArtifacts($scene) {
  const packagesDir = path.resolve(__dirname, '../../packages');
  const packages = fs.readdirSync(packagesDir);

  packages.forEach(pkg => {
    const pkgPath = path.join(packagesDir, pkg);
    const distZipPath = path.join(pkgPath, `${$scene}.zip`);
    const distDir = path.join(pkgPath, 'dist');

    // console.log('distZipPath', distZipPath);

    // 创建一个临时目录用于解压缩文件
    const tempUnzipPath = path.join(pkgPath, `${$scene}-temp`);

    try {
      execSync(`fx download-artifact --name "${pkg}_${$scene}.${FX_BUILD_ID}" --path "${distZipPath}"`);
      if (fs.existsSync(distZipPath)) {
        console.log(`========================== ${distZipPath} 开始解压 ==========================`);
        // 将 .zip 文件解压到临时目录
        execSync(`unzip "${distZipPath}" -d "${tempUnzipPath}"`);
        // 将临时目录中的文件复制到包的目录中
        copy(tempUnzipPath, distDir);
        // 删除临时目录/删除原始的 .zip 文件
        fs.rmSync(tempUnzipPath, { recursive: true, force: true });
        fs.unlinkSync(distZipPath);
      }
      // console.log(`========================== 解压 ${pkg}_${$scene}.${FX_BUILD_ID} 成功 ==========================`);
    } catch (error) {
      console.error(`Failed to download or unzip ${$scene} for package ${pkg}:`, error);
      console.log(`========================== 解压 ${$scene} 失败 ==========================`);
    }
  });
}

module.exports = {
  cwd,
  destPath,
  projectNameToDir,
  safeParse,
  cleanDist,
  clearDirectory,
  copy,
  getPackagesVersions,
  ensureOnBranch,
  deleteExistingTag,
  downloadAndUnzipArtifacts,
  fxJsonContent,
  indexSrcPath,
  fxJsonSrcPath
}