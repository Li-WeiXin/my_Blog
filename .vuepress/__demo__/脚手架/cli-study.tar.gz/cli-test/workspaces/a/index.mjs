import chalk from 'chalk';

export default function() {
  console.log(chalk.red('hello a'));
}
