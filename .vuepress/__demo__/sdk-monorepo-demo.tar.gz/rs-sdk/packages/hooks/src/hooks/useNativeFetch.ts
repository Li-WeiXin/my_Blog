import { isInApp } from "../helpers";
import { fetch, getInterceptorHandler, UseInterceptors } from './useFetch';
import { ref, computed } from 'vue';

interface FetchParams {
  method?: 'post' | 'get';
  params?: Record<string, any>;
  data?: Record<string, any>;
  url?: string;
}
interface NativeFetchParams {
  method: 'post' | 'get';
  path: string;
  query_params?: Record<string, any>;
  body_params?: Record<string, any>;
}
export const nativeFetch = async <T>(url: string, config: FetchParams & {
  _useInterceptors?: UseInterceptors;
  transformResponse?: (data: any) => T;
}, _forceDowngrade = false)
: Promise<T> => {
  if (_forceDowngrade || !isInApp) {
    // fallback to web fetch
    return fetch<T>(config.url || url, config)
      .then((res) => {
        // unwrap axios response
        return res.data;
      });
  }

  // handle request interceptors
  if (config._useInterceptors) {
    const handler = getInterceptorHandler('request', {
      _useInterceptors: config._useInterceptors
    });

    try {
      config = handler(config as any) as any;
    } catch (ex) {}
  }

  // transform FetchParams into NativeFetchParams
  const params: NativeFetchParams = {
    method: config.method || 'get',
    path: config.url || url,
    query_params: config.params,
    body_params: config.data
  };
  const message = {
    event: 'native_api_request',
    params
  };
  return new Promise((resolve, reject) => {
    dsBridge.call('power_channel_method_by_h5', JSON.stringify(message), (value) => {
      if (value?.result_code === 'not_support') {
        // 如果 jsbridge 不支持，尝试 fallback 到 webview 的请求
        return resolve(nativeFetch(url, config, true));
      }
      if (value?.data?.request_jsonstring) {
        let data = JSON.parse(value.data.request_jsonstring);

        //handle response interceptors
        if (config._useInterceptors) {
          const handler = getInterceptorHandler('response', {
            _useInterceptors: config._useInterceptors
          });
      
          try {
            data = (handler({
              data,
              config
            } as any) as any).data;
          } catch (ex) {
            console.error(ex);
          }
        }

        // handle transformResponse
        if (config.transformResponse) {
          try {
            data = config.transformResponse(data);
          } catch (ex) {
            console.error(ex);
          }
        }

        return resolve(data);
      }
      return reject(value);
    });
  });
};

export default function useNativeFetch<T>(url: string, config: FetchParams & {
  _useInterceptors?: UseInterceptors
}, delayRequest = false) {
  const data = ref<T>();
  const error = ref<Error>();
  const loading = ref<boolean>(delayRequest ? false : true);

  function query(queryConfig = config, setLoading = true) {
    if (setLoading) {
      loading.value = true;
    }
    nativeFetch<T>(url, queryConfig)
      .then((res) => {
        data.value = res;
      })
      .catch((err) => {
        error.value = err;
      })
      .finally(() => {
        if (setLoading) {
          loading.value = false;
        }
      });
  }

  if (!delayRequest) query();

  return { data, error, loading, query };
};
