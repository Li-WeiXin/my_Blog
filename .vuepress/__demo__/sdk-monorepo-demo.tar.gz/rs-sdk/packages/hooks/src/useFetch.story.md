
# Getting Started

1. 配置 baseUrl: 在 ConfigProvider 能够识别的 config 文件中配置 apiBaseUrl: { [env: 'local' | 'test' | 'stg' | 'prod']: string }; 或者是通过 setFetch 在传入的 config 对象中配置 (不推荐)

2. vue 中可以调用 useNativeFetch，该方法在 web 上会 fallback 到 web 方法上

3. 通过 interceptors 来 intercept 请求，内置了接口字段驼峰转义的 interceptor，可按需开启

# API

## useFetch(url:string, config?: AxiosRequestConfig)
返回一个对象 `{data: Ref, error: Ref}`
```typescript

function useFetch<T>(url: string, config?: AxiosRequestConfig): {data, error}<T>
```

## 内置的 interceptors

可以通过 config 里的 _useInterceptors 开启。

### transformToCamelCase
开启对 response 进行下划线到驼峰的转义，例如：

```typescript

const { data, error } = useFetch(url, {
  _useInterceptors: [['transformToCamelCase']]
})
```

## 自定义 interceptor
自定义对 response 或者 request 进行修改。

```typescript

addInterceptor('request', (config) => {
    config.params['brand'] = 'alps';

    return config;
});
```

