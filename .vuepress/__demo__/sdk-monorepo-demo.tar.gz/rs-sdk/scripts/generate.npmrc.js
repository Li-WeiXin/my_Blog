const fs = require('fs');
const path = require('path');

const npmrcContent = `shamefully-hoist=true #在安装依赖时，所有依赖都会被提升到项目的根目录
auto-install-peers=true # 在安装依赖时，自动安装 peerDependencies
strict-peer-dependencies=false # 在安装依赖时，不检查 peerDependencies
link-workspace-packages=true # 链接本地依赖
prefer-workspace-packages=true  # 优先使用本地依赖
recursive-install=true # 递归安装依赖
always-auth=true

registry=https://npmmirror.nioint.com/
`;

const npmrcPath = path.resolve(__dirname, '../.npmrc');

fs.writeFileSync(npmrcPath, npmrcContent, 'utf8');
console.log('.npmrc 文件已生成');
