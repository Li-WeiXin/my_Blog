/// <reference types="vitest" />
import { createViteConfig } from '@nio-wad/fx-comp-kit/dist/vite.config.js';
import pkg from './package.json';

const config = createViteConfig({ name: pkg.name });
// @ts-ignore
config?.build?.rollupOptions?.external?.push(...['axios', '@nio-fe/nio-apm-plus']);
export default config;