# `init`

> TODO: description

## Usage

```
const init = require('init');

// TODO: DEMONSTRATE API
```
