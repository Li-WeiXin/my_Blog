const { exec } = require('node:child_process');

if (process.env.SKIP_FORMAT) {
  console.log('绕过代码格式化');
  process.exit(0);
}

console.log(`\x1b[1m\x1b[32m开始执行Prettier代码格式化和Eslint检测\x1b[0m`);

// todo: 可以直接把这个命令放到 lint-staged 里面，这样就可以直接从 lint-staged 获取文件列表
exec('git diff --name-only HEAD | xargs', (err, stdout, stderr) => {
  if (err) {
    console.log('prettier 执行遇到问题，请查看详情处理。本次先跳过');
    console.error(err);
    console.log(stderr);
    process.exit(0);
  }

  const files = stdout
    .trim()
    .split(' ')
    .filter((val) => val.includes('src'));

  if (files.length === 0) process.exit(0);

  console.log('checking prettier for ', files);
  exec(
    `npx --no-install prettier --no-error-on-unmatched-pattern -w ${files.join(' ')}`,
    (err, stdout, stderr) => {
      if (err) {
        console.error(err);
        process.exit(1);
      }
      console.log(stderr);
      const edited = stdout
        .split('\n')
        .filter((val) => val)
        .filter((val) => val.indexOf('unchanged') === -1);
      if (edited.length > 0) {
        console.log('以下文件被 prettier 格式化，请重新检查');
        console.log(edited.join('\n'));
        process.exit(1);
      }
    }
  );
});
