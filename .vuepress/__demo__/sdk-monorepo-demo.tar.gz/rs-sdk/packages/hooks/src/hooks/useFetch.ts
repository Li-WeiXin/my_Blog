import axios, { AxiosError, AxiosInstance, AxiosRequestConfig, AxiosResponse, InternalAxiosRequestConfig } from "axios";
import { getEnv } from "../helpers";
import { ref, computed } from 'vue';
import type { Ref, ComputedRef } from 'vue';
import { NioApmPlus, CustomEventData } from '@nio-fe/nio-apm-plus'
export interface NioApiResponse<T> {
  request_id: string;
  server_time: number;
  result_code: string;
  /** 这个是 pe 的字段，接口是否加密，app 能自动解密 */
  encrypt_type: 0 | 1;
  data: T
}
export interface FetchResponse<DataSchema> {
  data: Ref<DataSchema | undefined>;
  error: Ref<AxiosError<DataSchema> | undefined>;
  response?: Ref<AxiosResponse<DataSchema> | undefined>;
  loading: Ref<boolean>;
  query: (config?: UseFetchConfig) => void;
}
const env = getEnv();
interface ResponseInterceptor {
  <T>(response: {
    data: T;
    config: any;
  }) : {
    data: T;
    config: any;
  }
}
interface RequestInterceptor {
  <T extends AxiosRequestConfig>(config: T): T
}
const customInterceptors: {
  response: ResponseInterceptor[],
  request: RequestInterceptor[]
} = {
  response: [],
  request: []
};

type AddCustomInterceptorParams = {
  [K in keyof typeof customInterceptors]: [type: K, interceptor: (typeof customInterceptors)[K][number]]
}[keyof typeof customInterceptors];
function addInterceptor(type: 'response', interceptor: ResponseInterceptor): void
function addInterceptor(type: 'request', interceptor: RequestInterceptor): void
function addInterceptor(...args: AddCustomInterceptorParams): void {
  const [type, interceptor] = args;
  if (type === 'response') {
    customInterceptors[type].push(interceptor);
  } else {
    customInterceptors[type].push(interceptor);
  }
}
export { addInterceptor };

export function getInterceptorHandler<K extends 'request' | 'response'>(type: K, overrideConfig?: {
  _useInterceptors: UseInterceptors
}) {
  return {
    response(res: AxiosResponse) {
      const config: UseFetchConfig = overrideConfig || res.config;
      if (config._useInterceptors) {
        res = config._useInterceptors[0].reduce((prev, current, index) => {
          try {
            if (current in interceptors.response) {
              return interceptors.response[current as ResponseInterceptorNames](prev, config._useInterceptors?.[1]?.[index]);
            }
          } catch (ex) {
            console.error(ex);
          }
          return prev;
        }, res);
      }
      res = customInterceptors.response.reduce((prev, current) => {
        try {
          return current(prev) as any;
        } catch (ex) {
          console.error(ex);
        }
        return prev;
      }, res);
      return res;
    },
    request(config: InternalAxiosRequestConfig) {
      const { _useInterceptors }: UseFetchConfig = overrideConfig || config;
      if (_useInterceptors) {
        config = _useInterceptors[0].reduce((prev, current, index) => {
          try {
            if (current in interceptors.request) {
              return interceptors.request[current as RequestInterceptorNames](prev, _useInterceptors?.[1]?.[index]) as InternalAxiosRequestConfig;
            }
          } catch (ex) {
            console.error(ex);
          }
          return prev;
        }, config);
      }
      config = customInterceptors.request.reduce((prev, current) => {
        try {
          return current(prev);
        } catch (ex) {
          console.error(ex);
        }
        return prev;
      }, config)
      return config;
    }
  }[type];
}

export function createInstance(config: AxiosRequestConfig = {}) {
  let localConfig: any = {};
  try {
    // @ts-ignore
    localConfig = process.config && process.config.apiBaseUrl && {baseURL: process.config.apiBaseUrl[env]};
  } catch (ex) {
    console.warn('Failed to find config file, please check compile scripts');
  }
  const instance = axios.create({
    ...localConfig,
    ...config,
  });

  instance.interceptors.response.use(getInterceptorHandler('response'));
  instance.interceptors.request.use(getInterceptorHandler('request'));

  return instance;
}
export let fetch: AxiosInstance = createInstance();
export function setFetch(config: AxiosRequestConfig = {}) {
  fetch = createInstance(config);
}

export function transformToCamelCase(obj: Record<PropertyKey, any> | any[]) {
  return Object.entries(obj).reduce((prev, [key, value]) => {
    const newKey = key.replaceAll(/_([a-zA-Z0-9])/g, ($, $1) => { 
      return $1.toUpperCase(); 
    });
    if (typeof value === 'object') {
      prev[newKey] = transformToCamelCase(value);
    } else {
      prev[newKey] = value;
    }
    return prev;
  }, Array.isArray(obj) ? [] : {} as any);
}

/**
 * add built-in interceptors here
 */
export const interceptors = {
  request: {
    addCommonHeaders(config: AxiosRequestConfig = {}, headers?: Record<string, string>) {
      if (headers) {
        if (!config.headers) config.headers = {};
        Object.assign(config.headers, headers);
      }
      return config;
    },
    addCommonParams(config: AxiosRequestConfig = {}, params?: Record<string, string>) {
      if (params) {
        if (!config.params) config.params = {};
        Object.assign(config.params, params);
      }
      return config;
    }
  },
  response: {
    transformToCamelCase(res: any, params: unknown) {
      if (res.data) {
        res.data = transformToCamelCase(res.data);
      }

      return res;
    },
  }
};
Object.freeze(interceptors);
export type ResponseInterceptorNames = keyof (typeof interceptors.response);
export type RequestInterceptorNames = keyof (typeof interceptors.request);
export type InterceptorNames = keyof {
  [K in (ResponseInterceptorNames | RequestInterceptorNames)]: any
};
export type UseInterceptors = [names: InterceptorNames[], params?: any[]];

interface UseFetchConfig extends AxiosRequestConfig {
  _useInterceptors?: UseInterceptors
}

export default function useFetch<T>(url: string, config: UseFetchConfig = {}, delayRequest = false): FetchResponse<T> {
  const responseRef = ref<AxiosResponse<T>>();
  const dataRef = ref<T>();
  const errorRef = ref<AxiosError<T>>();
  const loading = ref<boolean>(delayRequest ? false : true);

  function query(queryConfig = config, setLoading = true) {
    if (setLoading) {
      loading.value = true;
    }
    fetch<T>(url, queryConfig)
      .then((res) => {
        dataRef.value = res.data;
        responseRef.value = res;
      })
      .catch((error) => {
        errorRef.value = error;
      })
      .finally(() => {
        if (setLoading) {
          loading.value = false;
        }
      });
  }

  if (!delayRequest) query();

  return {
    loading,
    data: dataRef,
    response: responseRef,
    error: errorRef,
    query
  };
}

// 使用 addInterceptor 方法添加 resultCode 不是 'success'的发送事件
addInterceptor('response', (res) => {
  const apmInstance = NioApmPlus.getDefaultInstance();
  // 获取响应数据中的 resultCode 和 requestId
  const result_code = (res.data as any).resultCode || (res.data as any).result_code;
  const request_id = (res.data as any).requestId || (res.data as any).request_id;
  const path = (res.config as any).url; // 从响应配置中获取请求路径
  // 检查 apmInstance 是否存在，并且 resultCode 不是 'success'
  if (apmInstance && result_code !== 'success') {
    apmInstance.sendEvent({
      name: 'result-code-not-success',
      categories: {
        path,
        result_code,
        request_id
      }
    });
  }
  return res;
});
