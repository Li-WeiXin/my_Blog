# Project Name
RS-SDK

## 发布流程 ✓
- [x] 自定义流水线改造（pnpm + lerna）
- [x] 支持增量修改npm发版
- [] test: 同时发布多个修改的npm包

## 文档站点 ✓
- [x] 暴露文档站点入口
- [] 文档站点独立域名申请
- [] 搭建文档站点首页
- [] 文档注释函数生成md文件，自动集成到文档站点

## 代码规范 ✓
- [x] 代码规范使用 prettier/eslint/husky/commitlint/lint-staged
- [x] 代码提交前自动格式化代码
- [] 直接把precommit命令放到 lint-staged 里面，这样就可以直接从 lint-staged 获取文件列表

## 可扩展 ✓
- [] 脚手架前期功能收集
- [] 可扩展的方式来添加新的工具函数
- [] 可扩展的方式来添加新的工具函数文档
- [] 可扩展的方式来添加新的工具函数测试用例

## 剩余pkg迁移
- [] npm包迁移改造

## 文档规范 ✓
- [] 函数注释规范
- [] npm包迁移改造文档

## 其他
- [] fx cli --type 限制去掉验证 @jon.chen