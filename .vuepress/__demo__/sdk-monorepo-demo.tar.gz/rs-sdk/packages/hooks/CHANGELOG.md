# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## 1.0.5-alpha.0 (2025-03-13)


### Features

* 资源服务-1.monorepo工具库搭建 2.自定义流水线脚本撰写 3.文档站点搭建预留 4.hooks通用库迁移 ([e59e9d6](https://git.nevint.com/up-frontend/rs-sdk/commits/e59e9d6fd34398888115d5680f018db7d5ebbf80))
* 资源服务工具库-1.某库的声明文件没找到-类型定义修复 2.子包npmrc取消ignore ([a64c05a](https://git.nevint.com/up-frontend/rs-sdk/commits/a64c05a84bfb0d058b8d5efeaf8abf494468e4c8))
