# RS-SDK

为了高效地维护和管理工具库，提供rs-sdk平台来收敛这些SDK，使用 Lerna 管理的单一代码库（monorepo）对SDK进行统一管理和集中维护，并建立统一的文档规范。

## 目录结构

```
rs-sdk
├── packages
│   ├── hooks
│   ├── config-provider
├── package.json
├── lerna.json
├── patches
│   ├── histoire+0.11.2.patch
├── tests
└── README.md
```

## 包说明

- **hooks**: 该包包含了一系列实用的工具函数，包括封装好的 `fetch` 请求、`nativeFetch` 方法以及 `useOptimizeImage` 函数等，旨在简化和优化开发过程中的常见操作。


## 安装依赖

开发建议使用node 16版本

在根目录下运行以下命令以安装所有依赖：

```
npm run init:install && npm run bootstrap
```

## 使用 Lerna

使用 Lerna 管理包的版本和发布。可以使用以下命令：

- 启动开发环境：

```
pnpm run dev:hooks
```

- 发布新版本：

```
npx lerna publish
```

- sdk.json
> 用于处理打包时的配置
1. 从 sdk.json 中获取需要构建的项目
2. 从项目的 package.json 中获取需要上传的文件
3. npm包复制文件到 pkg-temp 目录下 
4. 文档复制文件到 doc-temp 目录下

-scripts
> 脚本文件

## 旧工具库迁移
- histoire.config.ts 改动 base路径
- tsconfig.json typeRoots适配

## 贡献

欢迎贡献代码！请提交 Pull Request 或者提出 Issues。

## 许可证

该项目遵循 MIT 许可证。