# @rs-sdk/shared 共享包

## 项目简介

`@rs-sdk/shared` 是一个共享包，包含了一些常用的常量和工程化配置，可以在多个项目中复用。

## 安装

在各个子项目中使用 `pnpm` 安装：
pnpm add @rs-sdk/shared --workspace

## 目录结构

## 配置规范共享
1. eslint规范共享
   
2. commit规范共享
   
3. prettier规范共享